public class Person {

    public String name;


}